This project includes build targets that will fail to build.

This is used to verify that `buck build --keep-going --build-report` will still
produce a build report when there are failing targets.
