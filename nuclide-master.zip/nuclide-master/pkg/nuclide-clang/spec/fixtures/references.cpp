#define RETURN(x) return x
void references_test(int var1) {
  int var2 = var1;
}
