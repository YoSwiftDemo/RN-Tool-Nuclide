void f(int x = 0) {
}

int main() {
  f();
  main(1);
  return 0
}
