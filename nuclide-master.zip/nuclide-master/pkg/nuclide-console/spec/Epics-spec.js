/**
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 *
 * @flow
 */

import type {AppState} from '../lib/types';

import {ActionsObservable} from '../../commons-node/redux-observable';
import * as Actions from '../lib/redux/Actions';
import * as Epics from '../lib/redux/Epics';
import invariant from 'assert';
import {Observable} from 'rxjs';

describe('Epics', () => {
  describe('registerOutputProviderEpic', () => {
    it('observes the status', () => {
      const mockStore = {
        dispatch: () => {},
        getState: () => (({}: any): AppState),
      };
      let setStatus;
      const provider = {
        id: 'test',
        messages: Observable.never(),
        observeStatus: cb => { setStatus = cb; },
        start: () => {},
        stop: () => {},
      };
      const actions = new ActionsObservable(
        Observable.of(Actions.registerOutputProvider(provider)),
      );
      const results = [];
      Epics.registerRecordProviderEpic(actions, mockStore).subscribe(results.push.bind(results));
      invariant(setStatus != null);
      setStatus('running');
      setStatus('stopped');
      setStatus('running');
      expect(results.length).toBe(3);
      expect(
        results.map(action => {
          invariant(action.type === Actions.UPDATE_STATUS);
          return action.payload.status;
        }),
      )
        .toEqual(['running', 'stopped', 'running']);
    });
  });
});
