---
id: blog
title: Blog
layout: redirect
destination: /
---
