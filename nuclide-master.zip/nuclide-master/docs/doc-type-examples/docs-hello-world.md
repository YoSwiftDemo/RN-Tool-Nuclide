---
docid: hello-world
title: Hello, World!
layout: docs
permalink: /docs/hello-world.html
---

Any local docs would go in the `_docs` directory.

## No documentation?

If you have no documentation for your site, you can remove the entire `_docs` folder. Otherwise add markdown files in here. See CONTRIBUTING.md for details.
